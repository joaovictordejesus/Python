n = int(input("Digite um valor de n: "))

cont=0

while cont < n:
 
    cont += 1
 
    print(cont)

print("fim")
