x = float(input("Digite um valor para x: "))

if x > 5:
    print("Maior que 5")

print("fim")
