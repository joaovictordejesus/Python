valor1 = 5
valor2 = 2
print("Tipo de valor1:", type(valor1))
print("Tipo de valor2:", type(valor2))
resultado = valor1 / valor2
print("Resultado da divisão:", resultado)
print("Tipo do resultado:", type(resultado))
