v1 = 10
v2 = 20

aux = v1
v1 = v2
v2 = aux

print("v1 após a troca:", v1)
print("v2 após a troca:", v2)
