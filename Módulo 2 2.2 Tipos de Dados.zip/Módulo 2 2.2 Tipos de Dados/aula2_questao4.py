saldo = 500.0
juros = 1.01


saldo *= juros
saldo *= juros
saldo *= juros

print("Após 3 meses meu novo saldo é:") 
print(saldo)
