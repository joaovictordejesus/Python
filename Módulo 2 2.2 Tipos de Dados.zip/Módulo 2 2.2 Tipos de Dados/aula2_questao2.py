texto = "o resultado é"
valor1 = 10
valor2 = 3.5
soma = valor1 + valor2

print("Texto:", texto)
print("Tipo de texto:", type(texto))

print("Valor1:", valor1)
print("Tipo de valor1:", type(valor1))

print("Valor2:", valor2)
print("Tipo de valor2:", type(valor2))

print("Soma:", soma)
print("Tipo da soma:", type(soma))
