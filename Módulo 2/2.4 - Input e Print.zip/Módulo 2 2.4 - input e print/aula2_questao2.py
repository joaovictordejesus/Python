print("Transformar fahrenheit em celsius")
fahrenheit = int(input("Digite a temperatura em graus Fahrenheit: "))
celsius = int((fahrenheit - 32) * (5/9))
print(f'{fahrenheit} graus Fahrenheit são {celsius} graus Celsius.')
