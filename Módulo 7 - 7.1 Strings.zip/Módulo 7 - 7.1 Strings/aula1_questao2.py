def boas_vindas():
    primeiro_nome = input("Digite seu primeiro nome: ")
    sobrenome = input("Digite seu sobrenome: ")
    print(f"Bem-vindo(a), {primeiro_nome} {sobrenome}!")

boas_vindas()